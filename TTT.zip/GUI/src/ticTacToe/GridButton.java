package ticTacToe;

import java.awt.*;

public class GridButton  extends Button {
   public int x = 0;
   public int y = 0;

    public GridButton(String s) {
        super (s);

    }
}
